package Aps;
import java.io.*;
import java.net.Socket;

public class Chat_Client {

    private static Socket socket;
    private static BufferedReader bufferedReader;
    private static BufferedWriter bufferedWriter;
    private static String username;
    static IntClient Int = new IntClient();
    static boolean MenSend;
    static String MenRead;
    
    public Chat_Client(Socket sock, String user) {
        try {
            socket = sock;
            username = user;
            bufferedReader = new BufferedReader(new InputStreamReader(sock.getInputStream()));
            bufferedWriter= new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
        } catch (IOException e) {
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }
    
    public static void sendMessage(String Men) {
    	  try {
    		  if (socket.isConnected()) {
    			  if (Men == null) {
    				  bufferedWriter.write(username);
    			  }
    			  
    			  else {
    				  bufferedWriter.write(username + ": " + Men);  
    			  }
    			  
                  bufferedWriter.newLine();
                  bufferedWriter.flush();
    		  }      
          } catch (IOException e) {
              closeEverything(socket, bufferedReader, bufferedWriter);
          }
    }
    
    public void listenForMessage() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String msgFromGroupChat;
                while (socket.isConnected()) {
                    try {
                        msgFromGroupChat = bufferedReader.readLine();
                        Env(msgFromGroupChat);
                    } catch (IOException e) {
                        closeEverything(socket, bufferedReader, bufferedWriter);
                    }
                }
            }
        }).start();
    }
    
    public static void Env(String Men) {
    	Int.Envio(Men);
    	
    }

    public static void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String Name,int Porta) throws IOException {

        String username = Name;
        Socket socket = new Socket("localhost", Porta);
        Chat_Client client = new Chat_Client(socket, username);
        client.listenForMessage();
        client.sendMessage(null);
    }
}
