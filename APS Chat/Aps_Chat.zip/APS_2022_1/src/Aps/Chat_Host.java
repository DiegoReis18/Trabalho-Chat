package Aps;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Chat_Host {
	
    private final ServerSocket serverSocket;
    static ArrayList<String> Nomes = new ArrayList<String>();
    static PessoaDAO Pessoa = new PessoaDAO();
    public Chat_Host(ServerSocket serverSocket) {
    this.serverSocket = serverSocket;
    }
    
   
    public static void Preenche() {
    	for (int x = 2; x < 1+Pessoa.contaPessoa(); x++) {
    		Nomes.add(Pessoa.selecionaNome(x) + " " +"	Offline");
    	}
    }
    
	public static void Online(String Nome, boolean On) {
		if (On == true) {
			for (int x = 0; x < Nomes.size(); x++) {
				 if (Nomes.get(x).startsWith(Nome)) {	
						Nomes.set(x, Nome+ " " + "	Online");
				}
			}
		}
		
		else{
			for (int x = 0; x < Nomes.size(); x++) {
				if (Nomes.get(x).startsWith(Nome)) {
					Nomes.set(x, Nome + " " +"	Offline");
				}
			}
		}
		
		IntHost.Atualiza();
	}
    

    public void startServer() {
        try {		
            while (!serverSocket.isClosed()) {
                Socket socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(socket);
                Online(clientHandler.getClientUsername(),true);
                
                for (int x = 0; x < Nomes.size(); x++) {
   				 if (Nomes.get(x).startsWith(clientHandler.getClientUsername())) {	
   						PessMensDAO psm = new PessMensDAO();
   						psm.atualizarEstado(x+2);
   				 	}
                }
                
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            closeServerSocket();
        }
    }

    public void closeServerSocket() {
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(int porta) throws IOException { 
    	Preenche();
		IntHost.Atualiza();
        ServerSocket serverSocket = new ServerSocket(porta);
        Chat_Host server = new Chat_Host(serverSocket);
        server.startServer();
    }

}

class ClientHandler implements Runnable {

    public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String clientUsername;
    static MensagemDAO Men = new MensagemDAO();

    public ClientHandler(Socket socket) {
        try {
            this.socket = socket;
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.bufferedWriter= new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.setClientUsername(bufferedReader.readLine());
            clientHandlers.add(this);
            loadMessage(getClientUsername());
            broadcastMessage("SERVER: " + getClientUsername() + " se conectou ao chat!");
        } catch (IOException e) {
            closeEverything(socket, bufferedReader, bufferedWriter);
        }
    }

    @Override
    public void run() {
        String messageFromClient;
        while (socket.isConnected()) {
            try {
                messageFromClient = bufferedReader.readLine();
                MensagemDAO men = new MensagemDAO();
                PessoaDAO pes = new PessoaDAO();
                PessMensDAO psm = new PessMensDAO();
                
                Men.inserir(messageFromClient);
                
                for (int x = 2; x < 1+pes.contaPessoa(); x++) {
            		if (messageFromClient.startsWith(pes.selecionaNome(x))) {
            			psm.inserir(x+2,men.contaMensagem());
            		}
            	}
                
				for (int x = 0; x < Chat_Host.Nomes.size(); x++) {
					if (Chat_Host.Nomes.get(x).contains("Online")) {
						psm.atualizarEstado(x+2);
					}
				}
				
                
                broadcastMessage(messageFromClient);
            } catch (IOException e) {
                closeEverything(socket, bufferedReader, bufferedWriter);
                break;
            }
        }
    }

    public void broadcastMessage(String messageToSend) {
        for (ClientHandler clientHandler : clientHandlers) {
            try {
                    clientHandler.bufferedWriter.write(messageToSend);
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
                
            } catch (IOException e) {
                closeEverything(socket, bufferedReader, bufferedWriter);
            }
        }
    }
   
    public void loadMessage(String Username) {
        for (ClientHandler clientHandler : clientHandlers) {
            try {
            	if(clientHandler.getClientUsername() == Username){
            		for (int x = 1; x < 1+Men.contaMensagem(); x++) {
                    clientHandler.bufferedWriter.write(Men.selecionaMensagem(x));
                    clientHandler.bufferedWriter.newLine();
                    clientHandler.bufferedWriter.flush();
            		}
            	}
            }
             catch (IOException e) {
                closeEverything(socket, bufferedReader, bufferedWriter);
            }
        }
    }
    
    public void removeClientHandler() {
        clientHandlers.remove(this);
        broadcastMessage("SERVER: " + getClientUsername() + " saiu do chat!");
        Chat_Host.Online(getClientUsername(),false);
    }

    public void closeEverything(Socket socket, BufferedReader bufferedReader, BufferedWriter bufferedWriter) {

        removeClientHandler();
        try {
            if (bufferedReader != null) {
                bufferedReader.close();
            }
            if (bufferedWriter != null) {
                bufferedWriter.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	public String getClientUsername() {
		return clientUsername;
	}

	public void setClientUsername(String clientUsername) {
		this.clientUsername = clientUsername;
	}
}
