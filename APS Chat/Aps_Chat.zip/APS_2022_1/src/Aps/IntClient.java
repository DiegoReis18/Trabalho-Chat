package Aps;


import java.io.*;
import java.net.Socket;
import java.text.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class IntClient extends JFrame implements ActionListener{  
    private JLabel label, l2, l3;
    private JEditorPane Mensagens;
    public JTextField texto;
    public JButton b1,b2,b3;
    private JPanel panel, panel2, panel3;
    private JScrollPane oi;
    BufferedImage imagem;
    public ArrayList<String> Mens; 
    ImageIcon Im1,Im2;

    public IntClient() {


        inicializar();
        configurar();
        inserindo();

        acao();
        setVisible(true);

        Vistos();
    }
    
    public void Vistos() {
    	psm.naoViu();
    		 if (Vistos.size()==0) {
                 b2.setBackground(new Color(3,187,133)); 
                 b2.setEnabled(false);
             }
             else {
                 b2.setBackground(new Color(139,0,0));
                 b2.setEnabled(true);
    		 
    	 } 
    }

    
    public void sendMessage() {
               	Chat_Client.sendMessage(texto.getText());
               	texto.setText("");
    }
       public void inicializar() {
    	Mens = new ArrayList<String>();
    	Im1 = new ImageIcon("");
    	Im2 = new ImageIcon("");
    	label = new JLabel ("Rio Tiet�");
    	l2 = new JLabel (Im1);
    	l3 = new JLabel (Im2);
    	Mensagens = new JEditorPane();
    	oi = new JScrollPane(Mensagens);
    	texto = new JTextField();
    	b1 = new JButton("Enviar");
    	b2 = new JButton("");
    	panel = new JPanel(new BorderLayout());
    	panel2 = new JPanel(new BorderLayout());
    	panel3 = new JPanel(new BorderLayout());
  
    	
    }
    public void configurar() {               
    	this.setMinimumSize(new Dimension(480,720));
		this.setTitle("Rio Tiet� Chat");
		this.setResizable(false);
		this.setBackground(Color.white);
		l2.setVisible(true);
		l3.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		
		panel2.setBackground(new Color(135,206,250));
		panel2.setSize(465,110);
		panel2.setLocation(0,-20);
		panel2.setBorder(BorderFactory.createLineBorder(Color.black));
		panel.setSize(465,30);
		panel.setLocation(0,650);
		panel.setBorder(BorderFactory.createLineBorder(Color.black));
		oi.setSize(350,500);  
		oi.setLocation(55,100);
		panel3.setSize(480,590);
		panel3.setLocation(0,60);
		b2.setLocation(420,300);
		b2.setSize(30,30);
		b2.addActionListener(this);
		b2.setBackground(new Color(0,128,128));
		b2.setBorder(BorderFactory.createLineBorder(Color.black));
		Mensagens.setBackground(new Color(48,77,106));	
		Mensagens.setContentType("text/html");           
		Mensagens.setEditable(false);
		oi.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		oi.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		texto.setSize(100,40);
    }
    
    public void inserindo() {
    
    	Im1 = new ImageIcon(getClass().getResource("Recursos/fundo.png"));
	    l2.setIcon(Im1);
	    Im2 = new ImageIcon(getClass().getResource("Recursos/ponte.png"));
	    l3.setIcon(Im2);
    	this.add(b2);
    	this.add(oi, BorderLayout.CENTER);
    	this.add(panel);
    	panel2.add(l3, BorderLayout.CENTER);
    	panel3.add(l2, BorderLayout.CENTER);
    	
    	panel.add(texto, BorderLayout.CENTER);
    	panel.add(b1, BorderLayout.EAST);
    	this.add(panel3);
    	this.add(panel2);
    
    }
    
    public void Envio(String mensagem) {
    	 		Vistos();
            	Mens.add("\n" + mensagem);
            	String msgFromGroupChat = "\n";
                   for (String aux : Mens) {
                	   msgFromGroupChat += ("<div style='background-color: rgb(140, 187, 242);padding: 3px; min-width: 20px; max-width: 100px; border-width: 2px; border-style: solid;border-radius: 10px; font-family: leelawadee'>"+aux+"</div><br>");
                       
                   }
                   Mensagens.setText(msgFromGroupChat);
          
    }
    
    public void acao() {
    	b1.addActionListener(event -> sendMessage()); 
    	b2.addActionListener(event -> b2.setBackground(new Color(139,0,0)));
    	b2.addActionListener(event -> b2.setBackground(new Color(176,224,230)));
    	
    	texto.addKeyListener(new KeyListener() {
    		public void keyPressed(KeyEvent e) { 
    			if(e.getKeyChar() == KeyEvent.VK_ENTER) {
    				sendMessage();
    			}
    		}

			
			public void keyTyped(KeyEvent e) {}

			
			public void keyReleased(KeyEvent e) {}
    	});
    }  
    
    
    static ArrayList<String> Vistos = new ArrayList<String>();
    static PessMensDAO psm = new PessMensDAO();
    static PessoaDAO Pes = new PessoaDAO();
    
    public static void Vistos(int Index) {
		if (Index == 1) {
			Vistos.removeAll(Vistos);
		}
		else
			Vistos.add(Pes.selecionaNome(Index));
    }
    
    public void actionPerformed(ActionEvent e)
    { 	
       if (e.getSource() == b2) {
    	   psm.naoViu();
    	   
           String msgFromGroupChat = "\n";
              for (String aux : Mens) {
                  msgFromGroupChat += ("<div style='background-color: rgb(140, 187, 242);padding: 3px; min-width: 20px; max-width: 100px; border-width: 2px; border-style: solid;border-radius: 10px; font-family: leelawadee'>"+aux+"</div><br>");

              }

            String msg3 = "";
              for(String aux2 : Vistos) {
                msg3 += (aux2+"<br>");

                   }
              String msgFromGroupChat2 = "<div style='background-color: yellow;padding: 3px; min-width: 20px; max-width: 100px; border-width: 2px; border-style: solid;border-radius: 10px; font-weight: bold; font-family: leelawadee'>N�o visualizado por:<br>"+msg3+"</div>";
              Mens.add("\n" + msgFromGroupChat2);
              Mensagens.setText(msgFromGroupChat+msgFromGroupChat2);

       		}
    	} 
    }