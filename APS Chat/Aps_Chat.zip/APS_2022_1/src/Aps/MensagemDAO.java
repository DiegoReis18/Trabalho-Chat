package Aps;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MensagemDAO {
    
    private Connection conexao;
    
    public MensagemDAO(){
    
        this.conexao = new ConnectionFactory().getConnection();
    
    }
    
    public void inserir(String conteudo){
    
        String sql = "INSERT INTO mensagem (conteudo)"
                    + "VALUE(?);";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, conteudo);
            
            stmt.execute();
            stmt.close();
        
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
    public int contaMensagem(){
    
        int count;
        
        String sql = "SELECT COUNT(conteudo) FROM mensagem";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            ResultSet rs = stmt.executeQuery();
            rs.next();
            count = rs.getInt(1);
            
            stmt.close();
            
            return count;
            
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
    public String selecionaMensagem(int id_mensagem){
    
        String conteudo = "";
        
        String sql = "SELECT conteudo FROM mensagem WHERE id_mensagem = ?";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, id_mensagem);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            conteudo = rs.getString(1);
            
            stmt.close();
            
            return conteudo;
            
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
}
