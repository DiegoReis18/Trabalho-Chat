package Aps;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class PessMensDAO {
    
    private Connection conexao;
    
    public PessMensDAO(){
    
        this.conexao = new ConnectionFactory().getConnection();
    
    }
    
    public void inserir(int id_pessoa, int id_mensagem){ //ser� passado o id de quem enviou a mensagem e o contaMensagem()
    
        PessoaDAO ps = new PessoaDAO();
        
        String sql = "INSERT INTO pessoa_mensagem (estado, id_pessoa, id_mensagem)"
                    + "VALUES(?, ?, ?);";
        
        for(int i = 1; i <= ps.contaPessoa(); i++){
        
            if(i != id_pessoa){
            
                try{
        
                    PreparedStatement stmt = conexao.prepareStatement(sql);
                    
                    stmt.setString(1, "n�o visto");
                    stmt.setInt(2, i);
                    stmt.setInt(3, id_mensagem);

                    stmt.execute();
                    stmt.close(); 
        
                }catch(SQLException excecao){

                    throw new RuntimeException(excecao);

                }
            
            }
        
        }
    
    }
    
    public void atualizarEstado(int id_pessoa){
    
        String sql = "UPDATE pessoa_mensagem SET estado = ? WHERE id_pessoa = ?";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setString(1, "visto");
            stmt.setInt(2, id_pessoa);
            
            stmt.execute();
            stmt.close(); 
        
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
    public void naoViu(){
    
        int[] id;
        id = new int[naoViuAux()];
        int aux = 0;
        IntClient.Vistos(1);
        
        String sql = "SELECT id_pessoa FROM pessoa_mensagem WHERE estado = ? ORDER BY id_pessoa";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
        
            stmt.setString(1, "n�o visto");
            
            ResultSet rs = stmt.executeQuery();
            rs.next();
            
            id[aux] = rs.getInt(1);
            aux++;
            
            while(rs.next()){
            
                if(id[aux-1] != rs.getInt(1)){
                
                    id[aux] = rs.getInt(1);
                    IntClient.Vistos(id[aux]);
                    aux++;
                
                }
            
            }
            
            stmt.close();
        
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
    public int naoViuAux(){
        
        int count;
        
        String sql = "SELECT COUNT(id_pessoa) FROM pessoa_mensagem WHERE estado = ?";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
        
            stmt.setString(1, "n�o visto");
            
            ResultSet rs = stmt.executeQuery();
            rs.next();
            count = rs.getInt(1);
            
            stmt.close();
        
            return count;
        
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
}
