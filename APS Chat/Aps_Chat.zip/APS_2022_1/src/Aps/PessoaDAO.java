package Aps;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaDAO {
    
    private Connection conexao;
    
    public PessoaDAO(){
    
        this.conexao = new ConnectionFactory().getConnection();
    
    }
    
    public int contaPessoa(){
    
        int count;
        
        String sql = "SELECT count(usuario) FROM login";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            ResultSet rs = stmt.executeQuery();
            rs.next();
            count = rs.getInt(1);
            
            stmt.close();
            
            return count;
            
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
    public String selecionaNome(int id_pessoa){
    
        String nome = "";
        
        String sql = "SELECT usuario FROM login WHERE id_pessoa = ?";
        
        try{
        
            PreparedStatement stmt = conexao.prepareStatement(sql);
            
            stmt.setInt(1, id_pessoa);
            ResultSet rs = stmt.executeQuery();
            rs.next();
            nome = rs.getString(1);
            
            stmt.close();
            
            return nome;
            
        }catch(SQLException excecao){
        
            throw new RuntimeException(excecao);
        
        }
    
    }
    
}
